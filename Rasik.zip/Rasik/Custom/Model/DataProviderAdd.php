<?php
namespace Rasik\Custom\Model;
 
use Rasik\Custom\Model\ResourceModel\Custom\CollectionFactory;
 
class DataProviderAdd extends \Magento\Ui\DataProvider\AbstractDataProvider
{
    /**
     * @param string $name
     * @param string $primaryFieldName
     * @param string $requestFieldName
     * @param CollectionFactory $customCollectionFactory
     * @param array $meta
     * @param array $data
     */
    public function __construct(
        $name,
        $primaryFieldName,
        $requestFieldName,
        CollectionFactory $customCollectionFactory,
        array $meta = [],
        array $data = []
    ) {
        $this->collection = $customCollectionFactory->create();
        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);
    }
 
    /**
     * Get data
     *
     * @return array
     */
    public function getData()
    {
        return [];
    }
}
